#!/usr/bin/env python3
"""
Automated Copywriting & Tone Transformer
DecodeLabs — Generative AI Project 2

Implements everything on the "Deployment Checklist" slide:
  1. Pydantic Models       -> GeneratedCopy (strict output schema)
  2. CLI Configuration     -> argparse captures product / tone / platform
  3. Master Instruction    -> f-string template locks in brand-safety +
     Template                platform constraints before the raw prompt
                              ever reaches the model
  4. Dual-Pipeline         -> single generations run directly; bulk CSV
                              jobs fan out through asyncio.gather behind
                              an asyncio.Semaphore, with tenacity retries
                              (exponential backoff + jitter) protecting
                              against rate limits

Usage:
    # single generation
    python3 copywriter.py --product "Wireless Earbuds" \
        --description "Noise-cancelling earbuds with 30hr battery" \
        --platform linkedin --tone professional

    # bulk generation from CSV (columns: product_name,description,platform,tone)
    python3 copywriter.py --csv products.csv --concurrency 5 --output results.json

    # offline self-test, no API key needed
    python3 copywriter.py --test
"""

import argparse
import asyncio
import csv
import json
import os
import sys
from typing import Optional

from pydantic import BaseModel, Field, ValidationError

try:
    import anthropic
except ImportError:
    print("Missing dependency. Install with:\n    pip install anthropic --break-system-packages")
    sys.exit(1)

try:
    from tenacity import (
        retry,
        stop_after_attempt,
        wait_random_exponential,
        retry_if_exception_type,
    )
except ImportError:
    print("Missing dependency. Install with:\n    pip install tenacity --break-system-packages")
    sys.exit(1)


DEFAULT_MODEL = "claude-sonnet-4-5"


# ---------------------------------------------------------------------------
# 1. Pydantic Models — strict output schema for the final copy generation
# ---------------------------------------------------------------------------
class GeneratedCopy(BaseModel):
    product_name: str
    platform: str
    tone: str
    headline: Optional[str] = None
    body: str
    hashtags: list[str] = Field(default_factory=list)
    character_count: int = 0

    def model_post_init(self, __context) -> None:
        # keep character_count honest regardless of what the model reported
        self.character_count = len(self.body)


class GenerationError(Exception):
    """Raised when the model's output can't be parsed/validated as GeneratedCopy."""


# ---------------------------------------------------------------------------
# Platform specs — the per-platform constraints baked into the master template
# ---------------------------------------------------------------------------
PLATFORM_SPECS = {
    "linkedin": {
        "max_chars": 3000,
        "style": "professional, thought-leadership tone, short paragraphs, ends with a call to action",
        "hashtags": True,
    },
    "instagram": {
        "max_chars": 2200,
        "style": "casual, visual-first, strong hook in the first line, emoji-friendly",
        "hashtags": True,
    },
    "email": {
        "max_chars": 1500,
        "style": "formal marketing email with a subject-line-style headline and a clear single call to action",
        "hashtags": False,
    },
    "twitter": {
        "max_chars": 280,
        "style": "punchy, concise, no fluff, every word earns its place",
        "hashtags": True,
    },
}


# ---------------------------------------------------------------------------
# 3. Master Instruction Template — the "locked" prompt compiler
# ---------------------------------------------------------------------------
def build_prompt(product_name: str, description: str, platform: str, tone: str) -> str:
    """
    Compiles user-supplied variables into a hidden master template via
    f-strings. The application layer is the gatekeeper: raw user facts go
    in, but the structural prompt itself — platform constraints, output
    schema, brand-safety guardrails — is fixed and cannot be overridden by
    the raw inputs.
    """
    platform_key = platform.lower().strip()
    if platform_key not in PLATFORM_SPECS:
        raise ValueError(f"Unsupported platform '{platform}'. Choose from: {list(PLATFORM_SPECS)}")

    spec = PLATFORM_SPECS[platform_key]
    hashtag_instruction = (
        "Include 3-5 relevant hashtags in the hashtags field."
        if spec["hashtags"]
        else "Do not include hashtags; leave hashtags as an empty list."
    )

    return f"""You are a professional marketing copywriter.

PRODUCT: {product_name}
DESCRIPTION: {description}
TARGET PLATFORM: {platform_key}
REQUESTED TONE: {tone}

PLATFORM RULES (must follow exactly):
- Style: {spec['style']}
- Hard character limit for the "body" field: {spec['max_chars']} characters.
- {hashtag_instruction}

OUTPUT FORMAT (strict):
Return ONLY a single JSON object, no markdown fences, no commentary, matching:
{{
  "product_name": string,
  "platform": "{platform_key}",
  "tone": string,
  "headline": string or null,
  "body": string,
  "hashtags": [string, ...]
}}
"""


# ---------------------------------------------------------------------------
# Parsing / validation
# ---------------------------------------------------------------------------
def parse_and_validate(raw_text: str) -> GeneratedCopy:
    cleaned = raw_text.strip()
    if cleaned.startswith("```"):
        # strip accidental markdown fences defensively
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:].strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise GenerationError(f"Model did not return valid JSON: {e}") from e

    try:
        return GeneratedCopy(**data)
    except ValidationError as e:
        raise GenerationError(f"Output failed schema validation: {e}") from e


def enforce_length(copy: GeneratedCopy) -> GeneratedCopy:
    """Belt-and-suspenders: hard-truncate if the model ignored the character limit."""
    spec = PLATFORM_SPECS.get(copy.platform.lower())
    if spec and copy.character_count > spec["max_chars"]:
        copy.body = copy.body[: spec["max_chars"] - 1].rstrip() + "…"
        copy.character_count = len(copy.body)
    return copy


# ---------------------------------------------------------------------------
# 4a. Single-generation pipeline (synchronous, for one-off runs)
# ---------------------------------------------------------------------------
def generate_single(
    client: "anthropic.Anthropic",
    product_name: str,
    description: str,
    platform: str,
    tone: str,
    temperature: float = 0.7,
    top_p: float = 1.0,
    model: str = DEFAULT_MODEL,
) -> GeneratedCopy:
    prompt = build_prompt(product_name, description, platform, tone)
    response = client.messages.create(
        model=model,
        max_tokens=800,
        temperature=temperature,
        top_p=top_p,
        messages=[{"role": "user", "content": prompt}],
    )
    text = "".join(b.text for b in response.content if getattr(b, "type", None) == "text")
    copy = parse_and_validate(text)
    return enforce_length(copy)


# ---------------------------------------------------------------------------
# 4b. Async bulk pipeline — Semaphore Gate + Tenacity Retry Shield
# ---------------------------------------------------------------------------
class RetryableAPIError(Exception):
    """Wraps transient errors (rate limits, timeouts) worth retrying."""


@retry(
    retry=retry_if_exception_type((RetryableAPIError, GenerationError)),
    wait=wait_random_exponential(multiplier=1, max=20),
    stop=stop_after_attempt(4),
    reraise=True,
)
async def _generate_one_async(
    client: "anthropic.AsyncAnthropic",
    semaphore: asyncio.Semaphore,
    row: dict,
    temperature: float,
    top_p: float,
    model: str,
) -> GeneratedCopy:
    prompt = build_prompt(row["product_name"], row["description"], row["platform"], row["tone"])
    async with semaphore:  # The Semaphore Gate — caps concurrent connections
        try:
            response = await client.messages.create(
                model=model,
                max_tokens=800,
                temperature=temperature,
                top_p=top_p,
                messages=[{"role": "user", "content": prompt}],
            )
        except anthropic.RateLimitError as e:
            raise RetryableAPIError(str(e)) from e
        except anthropic.APIConnectionError as e:
            raise RetryableAPIError(str(e)) from e

    text = "".join(b.text for b in response.content if getattr(b, "type", None) == "text")
    copy = parse_and_validate(text)  # raises GenerationError -> triggers retry
    return enforce_length(copy)


async def generate_bulk_async(
    rows: list[dict],
    api_key: str,
    concurrency: int = 5,
    temperature: float = 0.7,
    top_p: float = 1.0,
    model: str = DEFAULT_MODEL,
) -> list[dict]:
    """
    Fans out N generations concurrently, guaranteed to return results in the
    same order as the input rows (asyncio.gather semantics — chosen over
    as_completed because bulk CSV jobs need deterministic ordering to map
    back to the source file).
    """
    client = anthropic.AsyncAnthropic(api_key=api_key)
    semaphore = asyncio.Semaphore(concurrency)

    async def _task(row):
        try:
            result = await _generate_one_async(client, semaphore, row, temperature, top_p, model)
            return {"status": "ok", "row": row, "result": result.model_dump()}
        except Exception as e:  # noqa: BLE001 — isolate failures per-row, don't kill the batch
            return {"status": "error", "row": row, "error": str(e)}

    return await asyncio.gather(*[_task(r) for r in rows])


def load_csv_rows(path: str) -> list[dict]:
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append({
                "product_name": r["product_name"].strip(),
                "description": r["description"].strip(),
                "platform": r["platform"].strip().lower(),
                "tone": r["tone"].strip(),
            })
    return rows


# ---------------------------------------------------------------------------
# Offline self-test — proves prompt compilation, validation, retries, and
# concurrency all work correctly without spending API credits.
# ---------------------------------------------------------------------------
class _FakeTextBlock:
    def __init__(self, text):
        self.type = "text"
        self.text = text


class _FakeResponse:
    def __init__(self, text):
        self.content = [_FakeTextBlock(text)]


class _FakeAsyncMessages:
    """Scripted async client: fails once with bad JSON (to prove retry works),
    then succeeds; enforces character limits are respected in the prompt."""

    def __init__(self):
        self.calls = 0
        self.fail_once_ids = set()

    async def create(self, model, max_tokens, temperature, top_p, messages):
        self.calls += 1
        prompt = messages[0]["content"]

        # simulate a transient bad-output failure the FIRST time we see this exact prompt
        if prompt not in self.fail_once_ids:
            self.fail_once_ids.add(prompt)
            return _FakeResponse("not valid json at all")

        # extract product name back out of the prompt for a realistic reply
        import re
        m = re.search(r"PRODUCT: (.+)", prompt)
        product = m.group(1).strip() if m else "Unknown"
        platform_m = re.search(r"TARGET PLATFORM: (\w+)", prompt)
        platform = platform_m.group(1) if platform_m else "linkedin"
        tone_m = re.search(r"REQUESTED TONE: (.+)", prompt)
        tone = tone_m.group(1).strip() if tone_m else "professional"

        payload = {
            "product_name": product,
            "platform": platform,
            "tone": tone,
            "headline": f"{product}: Built Different",
            "body": f"Introducing {product} — engineered for people who expect more. " * 3,
            "hashtags": ["#launch", "#" + product.replace(" ", "")] if platform != "email" else [],
        }
        return _FakeResponse(json.dumps(payload))


class _FakeAsyncAnthropic:
    def __init__(self, api_key=None):
        self.messages = _FakeAsyncMessages()


async def run_self_test(verbose: bool = True) -> bool:
    import copywriter as _self  # noqa
    global anthropic

    rows = [
        {"product_name": "Aqua Bottle", "description": "Self-cleaning UV water bottle",
         "platform": "linkedin", "tone": "professional"},
        {"product_name": "Glow Lamp", "description": "Sunrise-simulation alarm lamp",
         "platform": "instagram", "tone": "playful"},
        {"product_name": "TaxEase", "description": "AI tax filing assistant for freelancers",
         "platform": "twitter", "tone": "confident"},
    ]

    ok = True

    # Test 1: prompt compilation includes all injected variables + platform rule
    p = build_prompt("Aqua Bottle", "Self-cleaning UV water bottle", "linkedin", "professional")
    checks = [
        "Aqua Bottle" in p,
        "Self-cleaning UV water bottle" in p,
        "linkedin" in p,
        "professional" in p,
        "3000 characters" in p,
    ]
    if verbose:
        print(f"[Prompt compilation] all variables injected: {all(checks)}")
    ok &= all(checks)

    # Test 2: invalid platform is rejected before ever touching the model
    try:
        build_prompt("X", "Y", "myspace", "casual")
        if verbose:
            print("[Platform validation] FAILED — accepted an unsupported platform")
        ok = False
    except ValueError:
        if verbose:
            print("[Platform validation] OK — rejected unsupported platform 'myspace'")

    # Test 3: async bulk pipeline with semaphore + tenacity retry-on-bad-output
    fake_client_holder = {}
    orig_async_client = anthropic.AsyncAnthropic
    anthropic.AsyncAnthropic = lambda api_key=None: _FakeAsyncAnthropic()
    try:
        results = await generate_bulk_async(rows, api_key="fake", concurrency=2)
    finally:
        anthropic.AsyncAnthropic = orig_async_client

    all_ok = all(r["status"] == "ok" for r in results)
    order_preserved = [r["row"]["product_name"] for r in results] == [r["product_name"] for r in rows]
    if verbose:
        for r in results:
            if r["status"] == "ok":
                cc = r["result"]["character_count"]
                print(f"[Bulk] {r['row']['product_name']} ({r['row']['platform']}) -> "
                      f"{cc} chars, retried-and-recovered from bad first output")
            else:
                print(f"[Bulk] {r['row']['product_name']} -> FAILED: {r['error']}")
    if verbose:
        print(f"[Bulk pipeline] all rows succeeded after retry: {all_ok}, order preserved: {order_preserved}")
    ok &= all_ok and order_preserved

    # Test 4: length enforcement truncates an oversized body
    oversized = GeneratedCopy(
        product_name="X", platform="twitter", tone="bold",
        body="x" * 500, hashtags=[],
    )
    trimmed = enforce_length(oversized)
    if verbose:
        print(f"[Length enforcement] twitter body trimmed to {trimmed.character_count} chars (limit 280): "
              f"{trimmed.character_count <= 280}")
    ok &= trimmed.character_count <= 280

    if verbose:
        print(f"\nSelf-test {'PASSED' if ok else 'FAILED'}")
    return ok


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Automated Copywriting & Tone Transformer")
    parser.add_argument("--product", help="Product name (single-generation mode)")
    parser.add_argument("--description", help="Raw product description (single-generation mode)")
    parser.add_argument("--platform", choices=list(PLATFORM_SPECS.keys()),
                         help="Target platform (single-generation mode)")
    parser.add_argument("--tone", default="professional", help="Desired tone (default: %(default)s)")
    parser.add_argument("--temperature", type=float, default=0.7, help="Sampling temperature (default: %(default)s)")
    parser.add_argument("--top-p", type=float, default=1.0, help="Top-P nucleus sampling (default: %(default)s)")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Model name (default: %(default)s)")
    parser.add_argument("--csv", help="Path to CSV for bulk mode (columns: product_name,description,platform,tone)")
    parser.add_argument("--concurrency", type=int, default=5, help="Max concurrent requests in bulk mode")
    parser.add_argument("--output", help="Path to write JSON results (bulk mode)")
    parser.add_argument("--test", action="store_true", help="Run the offline self-test")
    args = parser.parse_args()

    if args.test:
        ok = asyncio.run(run_self_test())
        sys.exit(0 if ok else 1)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("Set ANTHROPIC_API_KEY in your environment first, e.g.:\n"
              "    export ANTHROPIC_API_KEY=sk-ant-...")
        sys.exit(1)

    if args.csv:
        rows = load_csv_rows(args.csv)
        print(f"Loaded {len(rows)} rows from {args.csv}. Generating with concurrency={args.concurrency}...")
        results = asyncio.run(generate_bulk_async(
            rows, api_key=api_key, concurrency=args.concurrency,
            temperature=args.temperature, top_p=args.top_p, model=args.model,
        ))
        ok_count = sum(1 for r in results if r["status"] == "ok")
        print(f"Done: {ok_count}/{len(results)} succeeded.")
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2)
            print(f"Results written to {args.output}")
        else:
            print(json.dumps(results, indent=2))
        return

    if not (args.product and args.description and args.platform):
        print("Single-generation mode requires --product, --description, and --platform "
              "(or use --csv for bulk mode).")
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)
    copy = generate_single(
        client, args.product, args.description, args.platform, args.tone,
        temperature=args.temperature, top_p=args.top_p, model=args.model,
    )
    print(json.dumps(copy.model_dump(), indent=2))


if __name__ == "__main__":
    main()
